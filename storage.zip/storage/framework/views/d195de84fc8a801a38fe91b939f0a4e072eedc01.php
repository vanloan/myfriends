<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<?php if(count($errors) > 0): ?>
	    <div class="alert alert-danger">
	        <ul>
	            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	                <li><?php echo e($error); ?></li>
	            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	        </ul>
	    </div>
	<?php endif; ?>
	<form action="<?php echo e(route('public.up.index')); ?>" method="post" enctype="multipart/form-data" >
	<?php echo e(csrf_field()); ?>

		<input type="text" name="id" />
		<input type="text" name="name" />
		<input type="file" name="picture" />

		<input type="submit" name="submit" />
	</form>
</body>
</html>