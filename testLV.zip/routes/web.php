<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/
Route::pattern('id', '([0-9]+)');
Route::pattern('slug', '(.+)');

//public
Route::get('/',[
    'uses' => 'FriendsController@index', 
    'as' => 'public.friend.index'
]);
Route::get('{slug}-{id}',[
    'uses' => 'FriendsController@cat', 
    'as' => 'public.friend.cat'
]);
Route::get('{slug}-{id}.html',[
    'uses' => 'FriendsController@detail', 
    'as' => 'public.friend.detail'
]);

Route::get('lien-he',[
    'uses'=>'ContactsController@getContact',
    'as'=>'public.contacts.index'
    ]);

Route::post('lien-he',[
    'uses'=>'ContactsController@postContact',
    'as'=>'public.contacts.index'
    ]);

Route::get('video',[
    'uses' => 'VideoController@index', 
    'as' => 'public.video.index'
]);

Route::get('video/{slug}-{id}.asp',[
    'uses' => 'VideoController@cat', 
    'as' => 'public.video.cat'
]);

Route::get('video/{slug}-{id}.php',[
    'uses' => 'VideoController@detail', 
    'as' => 'public.video.detail'
]);

Route::get('search',[
    'uses' => 'SearchController@search', 
    'as' => 'public.search.index'
]);



Route::group(['namespace' => 'Admin', 'prefix' => 'admin','middleware'=>'auth'], function () {
    
    //cat controller

    Route::group(['prefix' => 'cat'], function () {
        Route::get('index', [
            'uses' => 'CatController@index',
            'as' => 'admin.cat.index'
        ]);
        Route::get('create', [
            'uses' => 'CatController@create',
            'as' => 'admin.cat.create'
        ]);
        Route::post('create', [
            'uses' => 'CatController@store',
            'as' => 'admin.cat.store'
        ]);
        Route::get('destroy/{id}', [
            'uses' => 'CatController@destroy',
            'as' => 'admin.cat.destroy'
        ]);
        
        Route::get('edit/{id}', [
            'uses' => 'CatController@edit',
            'as' => 'admin.cat.edit'
        ]);
        Route::post('update/{id}', [
            'uses' => 'CatController@update',
            'as' => 'admin.cat.update'
        ]);
    });

    //user controller

    Route::group(['prefix' => 'user', 'middleware' => 'role:admin'], function () {
        Route::get('index', [
            'uses' => 'UserController@index',
            'as' => 'admin.user.index'
        ]);
        Route::get('create', [
            'uses' => 'UserController@create',
            'as' => 'admin.user.create'
        ]);
        Route::post('create', [
            'uses' => 'UserController@store',
            'as' => 'admin.user.store'
        ]);
        Route::get('destroy/{id}', [
            'uses' => 'UserController@destroy',
            'as' => 'admin.user.destroy'
        ]);
        Route::get('edit/{id}', [
            'uses' => 'UserController@edit',
            'as' => 'admin.user.edit'
        ]);
        Route::post('update/{id}', [
            'uses' => 'UserController@update',
            'as' => 'admin.user.update'
        ]);
    });

    //friend controller

    Route::group(['prefix' => 'friend'], function () {
        Route::get('index', [
        	'uses' => 'FriendController@index',
        	'as' => 'admin.friend.index'
        ]);
        Route::get('create', [
        	'uses' => 'FriendController@create',
        	'as' => 'admin.friend.create'
        ]);
        Route::post('create', [
        	'uses' => 'FriendController@store',
        	'as' => 'admin.friend.store'
        ]);
        Route::get('destroy/{id}', [
    		'uses' => 'FriendController@destroy',
    		'as' => 'admin.friend.destroy'
    	]);
    	Route::get('edit/{id}', [
        	'uses' => 'FriendController@edit',
        	'as' => 'admin.friend.edit'
        ]);
        Route::post('update/{id}', [
        	'uses' => 'FriendController@update',
        	'as' => 'admin.friend.update'
        ]);
        Route::get('show/{id}', [
            'uses' => 'FriendController@show',
            'as' => 'admin.friend.show'
        ]);
        Route::get('index', [
            'uses' => 'FriendController@search',
            'as' => 'admin.friend.index'
        ]);
        
    });

    Route::group(['prefix' => 'video'], function () {
        Route::get('index', [
            'uses' => 'VideoController@index',
            'as' => 'admin.video.index'
        ]);
        Route::get('create', [
            'uses' => 'VideoController@create',
            'as' => 'admin.video.create'
        ]);
        Route::post('create', [
            'uses' => 'VideoController@store',
            'as' => 'admin.video.store'
        ]);
        Route::get('destroy/{id}', [
            'uses' => 'VideoController@destroy',
            'as' => 'admin.video.destroy'
        ]);
        
        Route::get('edit/{id}', [
            'uses' => 'VideoController@edit',
            'as' => 'admin.video.edit'
        ]);
        Route::post('update/{id}', [
            'uses' => 'VideoController@update',
            'as' => 'admin.video.update'
        ]);
    });
    
});

Route::group(['prefix' => 'auth', 'namespace' => 'Auth'], function () {
    Route::get('login', [
        'uses' => 'AuthController@getLogin',
        'as' => 'auth.login'
    ]);
    Route::post('login', [
        'uses' => 'AuthController@postLogin',
        'as' => 'auth.login'
    ]);
    Route::get('logout', [
        'uses' => 'AuthController@logout',
        'as' => 'auth.logout'
    ]);
});

Route::get('noaccess', function(){
    return view('noaccess');
});

Route::get('tao-pass', function(){
    return bcrypt('123456');
});


