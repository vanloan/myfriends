<?php $__env->startSection('main'); ?>
<div class="col-lg-12 col-md-12">
    <div class="card">
        <div class="header">
            <h4 class="title">Thêm thông tin</h4>
        </div>
        <div class="content">
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
            <form action="<?php echo e(route('admin.friend.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

                <div class="row">
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Họ tên</label>
                            <input type="text" name="name" class="form-control border-input" placeholder="Họ tên" value="">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="date">Ngày tạo</label>
                            <input type="text" name="created_at" value="" class="form-control border-input" placeholder="Ngày tạo">
                        </div>
                    </div>
                    <div class="col-md-1">
                        <div class="form-group">
                            <label for="read">Lượt đọc</label>
                            <input type="text" name="read" value="0" class="form-control border-input" placeholder="Lượt đọc">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Danh mục bạn bè</label>
                            <select name="friend_list" class="form-control border-input">
                            <?php $__currentLoopData = $arCats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $arCat): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <option value="<?php echo e($arCat['cid']); ?>"><?php echo e($arCat['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>   
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Hình ảnh</label>
                            <input type="file" name="picture" class="form-control" placeholder="Chọn ảnh" />
                        </div>
                    </div>
                    
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Mô tả</label>
                            <textarea id="ckeditor" rows="4" class="form-control border-input ckeditor" name="preview" ></textarea>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Chi tiết</label>
                            <textarea id="ckeditor" rows="6" class="form-control border-input ckeditor" name="content" ></textarea>
                        </div>
                    </div>
                </div>
                
                <div class="text-center">
                    <input type="submit" class="btn btn-info btn-fill btn-wd" value="Thực hiện" />
                </div>
                <div class="clearfix"></div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>