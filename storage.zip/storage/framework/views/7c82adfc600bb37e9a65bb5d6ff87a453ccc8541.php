<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container">
		<div class="content-grids">
			<div class="col-md-8 content-main">
				<div class="content-grid">
					<div class="content-grid-head">
						<h3><?php echo e($arFriend['name']); ?></h3>
						<h4>Đăng ngày: <?php echo e($arFriend['created_at']); ?> - Lượt xem: <?php echo e($arFriend['count_number']); ?></h4>
						<div class="clearfix"></div>
					</div>
					<div class="content-grid-single">
						<h3><?php echo e($arFriend['name']); ?></h3>
						<div class="detail_text">
							<span><?php echo $arFriend['preview']; ?></span>
							<img class="single-pic" src="<?php echo e(Storage::url('app/files/'.$arFriend['picture'])); ?>" alt="">
							<p><?php echo $arFriend['content']; ?></p>
						</div>
						<div class="comments">
							<h3>Bạn thân khác của tôi</h3>

							<?php $__currentLoopData = $tinLQs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tinLQ): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
								<?php 
									$id = $tinLQ['fid'];
									$name = $tinLQ['name'];
									$cat = $tinLQ['cat_id'];
									$nameSeo = str_slug($name);
									$picture = $tinLQ['picture'];
									$urlPic = Storage::url('app/files/'.$picture);
									$preview = $tinLQ['preview'];
									$link = route('public.friend.detail', ['slug' => $nameSeo, 'id' => $id]);
								?>
								<?php if(($arFriend['fid'] != $id) and ($arFriend['cat_id'] == $cat)): ?>
									<div class="comment-grid">
										<img src="<?php echo e($urlPic); ?>" alt="">
										<div class="comment-info">
											<h4><a href="<?php echo e($link); ?>"><?php echo e($name); ?></a></h4>
											<p><?php echo $preview; ?></p>
										</div>
										<div class="clearfix"></div>
									</div>
								<?php endif; ?>
								
							<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

						</div>
					</div>

				</div>			 			 
			</div>
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('templates.public.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>