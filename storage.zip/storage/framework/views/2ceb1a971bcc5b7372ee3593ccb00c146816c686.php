<?php $__env->startSection('content'); ?>

<div class="content">
	 <div class="container">
		 <div class="content-grids">
			 <div class="col-md-8 content-main">
			 	<h1 class="title"><span>Video >> </span><?php echo e($arDMV['name']); ?></h1>				 
				 <?php $__currentLoopData = $arVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $arVideo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					 <?php 
					 	$vid = $arVideo['vid'];
					 	$vname = $arVideo['name'];
					 	$vnameSeo = str_slug($vname);
					 	$youtube_code = $arVideo['youtube_code'];
					 	$created_at = $arVideo['created_at'];

					 	$vlink = route('public.video.detail', ['slug' => $vnameSeo, 'id' => $vid]);
					 ?>
				 <div class="content-grid-sec">
					 <div class="content-sec-info">
						 <h3><a href="<?php echo e($vlink); ?>"><?php echo e($vname); ?></a></h3>
						 
							 <h4>Đăng ngày: <?php echo e($created_at); ?></h4>
							 <iframe width="684" height="385" src="https://www.youtube.com/embed/<?php echo e($youtube_code); ?>?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>
							 
					 </div>
				 </div>
				 <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>		 
			 </div>
			 
		<div class="text-center"> 
		 	<?php echo e($arVideos->links()); ?> 
		</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.public.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>