<?php $__env->startSection('content'); ?>

<div class="content">
	 <div class="container">
		 <div class="content-grids">
			 <div class="col-md-8 content-main">				 
				 <h1 class="title"><?php echo e($arVideo['name']); ?></h1>
				 
				 <div class="content-grid-sec">
					 <div class="content-sec-info">
						 <h4>Đăng ngày: <?php echo e($arVideo['date_create']); ?></h4>
						 <iframe width="684" height="385" src="https://www.youtube.com/embed/<?php echo e($arVideo['youtube_code']); ?>?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>
							 
					 </div>
				 </div> 
			 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.public.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>