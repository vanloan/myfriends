<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Cat;
use App\Http\Requests\CatRequest;

class CatController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $arCats = Cat::all();
        return view('admin.cat.index', ['arCats' => $arCats]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.cat.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CatRequest $request)
    {
        $arCat = array(
            'name' => $request->name
        );
        Cat::insert($arCat);
        $request->session()->flash('msg', 'Thêm thành công');
        return redirect()->route('admin.cat.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $arCat = Cat::find($id);
        return view('admin.cat.edit', ['arCat' => $arCat]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $arCat = Cat::find($id);
        $arCat->name = $request->name;
        $arCat->Update();

        $request->session()->flash('msg', 'Sửa thành công');
        return redirect()->route('admin.cat.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id, Request $request)
    {
        $arCat = Cat::find($id);
        $arCat->delete();
        $request->session()->flash('msg', 'Xóa thành công');
        return redirect()->route('admin.cat.index');
    }
}
