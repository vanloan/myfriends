<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\DB;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        $arDMTs = DB::table('cats')->get();
        View::share('arDMTs', $arDMTs);
        $arDMVs = DB::table('videos')->get();
        View::share('arDMVs', $arDMVs);
        
        View::share('adminUrl', '/resources/assets/templates/admin');
        View::share('publicUrl', '/resources/assets/templates/public');
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
