<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Friend extends Model
{
    protected $table = 'friends';
    protected $primaryKey = 'fid';
    public $timestamps = false;

    public static function getList(){
    	return DB::table('friends as f')->join('cats as c', 'f.cat_id', '=', 'c.cid')->orderBy('fid', 'DESC')->select('*','f.name as name', 'c.name as cname')->paginate(getenv('ROW_COUNT'));
    }
    
}
