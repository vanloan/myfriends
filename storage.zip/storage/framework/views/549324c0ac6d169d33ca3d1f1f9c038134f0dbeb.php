<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container">
		<div class="content-grids">
			<div class="col-md-8 content-main">				 
				<h1 class="title">Những người bạn</h1>
				<?php $__currentLoopData = $arFriends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $arFriend): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

				<?php 
				 	$id = $arFriend['fid'];
				 	$name = $arFriend['name'];
				 	$nameSeo = str_slug($name);

				 	$preview = $arFriend['preview'];
				 	$content = $arFriend['content'];
				 	$created_at = $arFriend['created_at'];
				 	$cid = $arFriend['cat_id'];
				 	$count_number = $arFriend['count_number'];
				 	$picture = $arFriend['picture'];
				 	$urlPic = Storage::url('app/files/'.$picture);

				 	$link = route('public.friend.detail', ['slug' => $nameSeo, 'id' => $id]);
				?>

					<div class="content-grid-sec">
						<div class="content-sec-info">
								<h3><a href="<?php echo e($link); ?>"> <?php echo e($name); ?> </a></h3>
								<h4>Đăng ngày: <?php echo e($created_at); ?> - Lượt xem: <?php echo e($count_number); ?> </h4>
								<p><?php echo $preview; ?></p>
								<img src="<?php echo e($urlPic); ?>" width="50%" alt=""/>
								<a class="bttn" name="count_number" href="<?php echo e($link); ?>">Chi  tiết bạn tôi</a>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				
				<div class="text-center">
                	<?php echo e($arFriends->links()); ?>

            	</div>
            	
			</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.public.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>