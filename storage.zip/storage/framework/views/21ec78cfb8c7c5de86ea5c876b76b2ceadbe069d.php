<?php $__env->startSection('main'); ?>

<div class="col-md-12">
    <div class="card">
        <div class="header">
            <h4 class="title">Danh sánh Username</h4>

            <?php if(Session::get('msg') != ''): ?>
            <p class="category success"><?php echo e(Session::get('msg')); ?></p>
            <?php endif; ?>
            
            <a href="<?php echo e(route('admin.user.create')); ?>" class="addtop"><img src="<?php echo e($adminUrl); ?>/img/add.png" alt="" /> Thêm</a>
        </div>
        <div class="content table-responsive table-full-width">
            <table class="table table-striped">
                <thead>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Fullname</th>
                    <th>Chức năng</th>
                </thead>
                <tbody>
                <?php $__currentLoopData = $arUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $arUser): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <?php 
                    $uid = $arUser['id'];
                    $username = $arUser['username'];
                    $fullname = $arUser['fullname'];
                    
                    $urlEdit = route('admin.user.edit', $uid);
                    $urlDel = route('admin.user.destroy', $uid);
                ?>
                    <tr>
                        <td><?php echo e($uid); ?></td>
                        <td><a href="<?php echo e($urlEdit); ?>"><?php echo e($username); ?></a></td>
                        <td><?php echo e($fullname); ?></td>
                        <td>
                            <a href="<?php echo e($urlEdit); ?>"><img src="<?php echo e($adminUrl); ?>/img/edit.gif" alt="" /> Sửa</a> &nbsp;||&nbsp;
                            <a href="<?php echo e($urlDel); ?>"><img src="<?php echo e($adminUrl); ?>/img/del.gif" alt="" /> Xóa</a>
                        </td>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>

            </table>
 
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>