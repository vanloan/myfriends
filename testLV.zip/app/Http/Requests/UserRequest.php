<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'username' => 'required|min:6|max:255',
            'password' => 'required|min:6|max:255',
            'fullname' => 'required|min:6|max:200',
        ];
    }
    public function messages()
    {
        return [
            'username.required' => 'Nhập username',
            'username.min' => 'Nhập username tối thiểu 6 ký tự',
            'username.max' => 'Nhập username tối đa 255 ký tự',
            'password.required' => 'Nhập password',
            'password.min' => 'Nhập password tối thiểu 6 ký tự',
            'password.max' => 'Nhập password tối đa 255 ký tự',
            'fullname.required' => 'Nhập fullname',
            'fullname.min' => 'Nhập fullname tối thiểu 6 ký tự',
            'fullname.max' => 'Nhập fullname tối đa 200 ký tự',
            
        ];
    }
}
