<?php $__env->startSection('main'); ?>
<div class="col-lg-12 col-md-12">
    <div class="card">
        <div class="header">
            <h4 class="title">Thêm User</h4>
        </div>
        <div class="content">
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('admin.user.store')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

                <div class="row">
                    
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" name="username" class="form-control border-input" placeholder="Nhập Username" value="">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control border-input" placeholder="Nhập Password" value="">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Fullname</label>
                            <input type="text" name="fullname" class="form-control border-input" placeholder="Nhập họ tên" value="">
                        </div>
                    </div>
                    
                </div>
                <div class="text-center">
                    <input type="submit" class="btn btn-info btn-fill btn-wd" value="Thực hiện" />
                </div>
                <div class="clearfix"></div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>