<?php $__env->startSection('content'); ?>
<?php
    function doiMau($str, $search){
        return str_replace($search, "<span style='background:yellow;'>$search</span>", $str);
    }
?>
<div class="content">
	 <div class="container">
		 <div class="content-grids">
			 <div class="col-md-8 content-main">				 
				<h1 class="title"><span>Search >> </span><?php echo e($search); ?></h1>
				<?php $__currentLoopData = $arFriends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $arFriend): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

				<?php 
				 	$id = $arFriend['fid'];
				 	$name = $arFriend['name'];
				 	$nameSeo = str_slug($name);

				 	$preview = $arFriend['preview'];

				 	$created_at = $arFriend['created_at'];
				 
				 	$read = $arFriend['count_number'];
				 	$picture = $arFriend['picture'];
				 	$urlPic = Storage::url('app/files/'.$picture);

				 	$link = route('public.friend.detail', ['slug' => $nameSeo, 'id' => $id]);
				?>
				 <div class="content-grid-sec">
					 <div class="content-sec-info">
						 <h3><a href="<?php echo e($link); ?>"><?php echo doiMau($name, $search); ?></a></h3>
						 <h4>Đăng ngày: <?php echo e($created_at); ?> - Lượt xem: <?php echo e($read); ?></h4>
						 <p><?php echo doiMau($preview, $search); ?></p>
						 <img src="<?php echo e($urlPic); ?>" alt=""/>
						 <a class="bttn" href="<?php echo e($link); ?>">Chi tiết bạn tôi</a>
					 </div>
				 </div>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				
				<?php $__currentLoopData = $arVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $arVideo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					 <?php 
					 	$vid = $arVideo['vid'];
					 	$vname = $arVideo['name'];
					 	$vnameSeo = str_slug($vname);
					 	$youtube_code = $arVideo['youtube_code'];
					 	$created_at = $arVideo['created_at'];

					 	$vlink = route('public.video.detail', ['slug' => $vnameSeo, 'id' => $vid]);
					 ?>
				 <div class="content-grid-sec">
					 <div class="content-sec-info">
						 <h3><a href="<?php echo e($vlink); ?>"><?php echo doiMau($vname, $search); ?></a></h3>
						 
							 <h4>Đăng ngày: <?php echo e($created_at); ?></h4>
							 <iframe width="684" height="385" src="https://www.youtube.com/embed/<?php echo e($youtube_code); ?>?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>
							 
					 </div>
				 </div>
				 <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			 </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('templates.public.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>