<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;

class AuthController extends Controller
{
    public function getLogin(){
    	return view('auth.login');
    }
    public function postLogin(Request $request){
    	$username = $request->username;
    	$password = $request->password;

    	if (Auth::attempt(['username' => $username,'password' => $password])){
    		return redirect()->route('admin.user.index');
    	} else {
    		$request->session()->flash('msg', 'Sai Username hoặc password');
    		return redirect()->route('auth.login');
    	}
    }
    
    public function logout(Request $request){
    	Auth::logout();
    	return redirect()->route('public.friend.index');
    }
}
