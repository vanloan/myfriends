<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Video;
use App\Http\Requests\VideoRequest;

class VideoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $arVideos = Video::all();
        return view('admin.video.index', ['arVideos' => $arVideos]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.video.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(VideoRequest $request)
    {
        $arVideo = array(
            'name' => $request->name,
            'youtube_code' => $request->youtube_code,
        );
        Video::insert($arVideo);
        $request->session()->flash('msg', 'Thêm thành công');
        return redirect()->route('admin.video.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $arVideo = Video::find($id);
        return view('admin.video.edit', ['arVideo' => $arVideo]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $arVideo = Video::find($id);
        $arVideo->name = $request->name;
        $arVideo->Update();

        $request->session()->flash('msg', 'Sửa thành công');
        return redirect()->route('admin.video.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id, Request $request)
    {
        $arVideo = Video::find($id);
        $arVideo->delete();
        $request->session()->flash('msg', 'Xóa thành công');
        return redirect()->route('admin.cat.index');
    }
}
