<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Video;

class VideoController extends Controller
{
	public function index(){

    	$arVideos = Video::orderBy('vid', 'DESC')->
    	paginate(getenv('ROW_COUNT'));
    	return view('video.index', ['arVideos' => $arVideos]);
    }
    
    public function cat($slug, $cid){

    	$arDMV = Video::find($cid);

    	$arVideos = Video::where('vid', '=', $cid)->orderBy('vid', 'DESC')->
    	                                   paginate(getenv('ROW_COUNT'));
    	return view('video.cat', ['arVideos' => $arVideos], ['arDMV' => $arDMV]);
    }

    public function detail($slug, $id){

        $arVideo = Video::find($id);
    	return view('video.detail', ['arVideo' => $arVideo]);
    }

    public function search(Request $request){
        $search = $request->search;

        $arVideos = Video::where('name','like',"%$search%")->paginate(getenv('ROW_COUNT'));
        return view('video.search',['arVideos'=>$arVideos, 'search'=>$search]);

    }
}
