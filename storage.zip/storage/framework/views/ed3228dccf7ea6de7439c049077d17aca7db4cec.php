<?php echo $__env->make('templates.admin.header2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <?php echo $__env->yieldContent('main2'); ?>
        </div>
    </div>
</div>

<?php echo $__env->make('templates.admin.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
