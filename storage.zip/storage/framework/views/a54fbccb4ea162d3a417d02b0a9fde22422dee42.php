<?php $__env->startSection('content'); ?>
<div class="contact">

	<div class="container">
		<div class="contact-head">
			<h3>Liên hệ</h3>
				<?php if(count($errors) > 0): ?>
		            <div class="alert alert-danger">
		                <ul>
		                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                        <li><?php echo e($error); ?></li>
		                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		                </ul>
		            </div>
		        <?php endif; ?>
			<form action="<?php echo e(route('public.contacts.index')); ?>" method="POST" enctype="multipart/form-data">
			  <?php echo e(csrf_field()); ?>


				<div class="col-md-4 contact-left">

					<input type="text" name="name" placeholder="Name">
					<input type="text" name="email" placeholder="E-mail">
					<input type="text" name="phone" placeholder="Phone">
				</div>
				<div class="col-md-8 contact-right">
				 	<textarea id="ckeditor" class="form-control border-input ckeditor" name="message" ></textarea>
					<input type="submit" value="SEND">
				</div>
				<div class="clearfix"></div>
			</form>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.public.template2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>