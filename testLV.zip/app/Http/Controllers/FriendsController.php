<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use App\Cat;
use App\Friend;
use App\Video;



class FriendsController extends Controller
{
    public function index(){
        
    	$arFriends = Friend::getList();
    	return view('friend.index', ['arFriends' => $arFriends]);
    }
    public function cat($slug, $cid){

    	$arCat = Cat::find($cid);
        
    	$arFriends = Friend::where('cat_id', '=', $cid)->
    	orderBy('fid', 'DESC')->
    	paginate(getenv('ROW_COUNT'));
    	return view('friend.cat', ['arFriends' => $arFriends, 'arCat' => $arCat]);
    }
    public function detail($slug, $id){
        // tăng lượt view

        $blogKey = 'blog_' . $id;
        if (!Session::has($blogKey)) {
            Friend::where('fid', $id)->increment('count_number');
            Session::put($blogKey, 1);
        }
        
        ////////////

        $arFriend = Friend::find($id);
        $tinLQs = Friend::all();
    	return view('friend.detail', ['arFriend'=>$arFriend, 'tinLQs'=>$tinLQs, 'blogKey'=>$blogKey]);
    }
    public function search(Request $request){
        $search = $request->search;

        $arFriends = Friend::where('name','like',"%$search%")->orWhere('preview','like',"%$search%")->paginate(getenv('ROW_COUNT'));
        return view('friend.search',['arFriends'=>$arFriends, 'search'=>$search]);

    }
}
