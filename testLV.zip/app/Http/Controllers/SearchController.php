<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Video;
use App\Friend;

class SearchController extends Controller
{
	
    public function search(Request $request){
        $search = $request->search;

        $arFriends = Friend::where('name','like',"%$search%")->orWhere('preview','like',"%$search%")->paginate(getenv('ROW_COUNT'));
        $arVideos = Video::where('name','like',"%$search%")->paginate(getenv('ROW_COUNT'));
        return view('search.index',['arFriends'=>$arFriends,'arVideos'=>$arVideos, 'search'=>$search]);

    }
}
