
			<div class="col-md-4 content-main-right">
				<div class="search">
				<h3>TÌM BẠN TÔI</h3>
				<form action="<?php echo e(route('public.search.index')); ?>" method="get" >
				<?php echo e(csrf_field()); ?>

					<input type="text" name="search" placeholder="Search" >
					<input type="submit" value="">
				</form>
				</div>

				<div class="categories">
					<h3>DANH MỤC BẠN BÈ</h3>
					<?php $__currentLoopData = $arDMTs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $arDMT): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

					<?php 
					 	$cid = $arDMT['cid'];
					 	$cname = $arDMT['name'];
					 	$cnameSeo = str_slug($cname);

					 	$link = route('public.friend.cat', ['slug' => $cnameSeo, 'id' => $cid]);

					?>
						<li><a href="<?php echo e($link); ?>"><?php echo e($cname); ?></a></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</div>

				<div class="categories">
					<h3>Video hành trình</h3>
					<?php $__currentLoopData = $arDMVs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $arDMV): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

					<?php 
					 	$vid = $arDMV['vid'];
					 	$vname = $arDMV['name'];
					 	$vnameSeo = str_slug($vname);

					 	$vlink = route('public.video.cat', ['slug' => $vnameSeo, 'id' => $vid]);

					?>
					<li><a href="<?php echo e($vlink); ?>"><?php echo e($vname); ?></a></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</div>

				<div class="archives">
				<h3>Liên kết VinaEnter</h3>

				<li><a href="http://vinaenter.edu.vn/lap-trinh-android-tu-az.html" target="_blank"><img width="100%" src="<?php echo e($publicUrl); ?>/images/android.png" alt="" /></a></li>
				</div>
			</div>			
			<div class="clearfix"></div>
		</div>
	</div>
</div>