<?php $__env->startSection('main'); ?>

<div class="col-md-12">
    <div class="card">
        <div class="header">
            <h4 class="title">Danh mục bạn bè</h4>

            <?php if(Session::get('msg') != ''): ?>
            <p class="category success"><?php echo e(Session::get('msg')); ?></p>
            <?php endif; ?>
            
            <a href="<?php echo e(route('admin.cat.create')); ?>" class="addtop"><img src="<?php echo e($adminUrl); ?>/img/add.png" alt="" /> Thêm</a>
        </div>
        <div class="content table-responsive table-full-width">
            <table class="table table-striped">
                <thead>
                    <th>ID</th>
                    <th>Tên danh mục</th>
                    <th>Chức năng</th>
                </thead>
                <tbody>
                <?php $__currentLoopData = $arCats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $arCat): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <?php 
                    $cid = $arCat['cid'];
                    $name = $arCat['name'];
                    $nameSeo = str_slug($name);
                    $urlEdit = route('admin.cat.edit', $cid);
                    $urlDel = route('admin.cat.destroy', $cid);
                ?>
                    <tr>
                        <td><?php echo e($cid); ?></td>
                        <td><?php echo e($name); ?></td>
                        <td>
                            <a href="<?php echo e($urlEdit); ?>"><img src="<?php echo e($adminUrl); ?>/img/edit.gif" alt="" /> Sửa</a> &nbsp;||&nbsp;
                            <a href="<?php echo e($urlDel); ?>"><img src="<?php echo e($adminUrl); ?>/img/del.gif" alt="" /> Xóa</a>
                        </td>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>

            </table>
 
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>