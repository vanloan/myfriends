<?php $__env->startSection('main'); ?>

<div class="col-md-12">
    <div class="card">
        <div class="header">
            <h4 class="title">Search >> <?php echo e($fullname); ?></h4>
            <?php if(Session::get('msg') != ''): ?>
            <p class="category success"><?php echo e(Session::get('msg')); ?></p>
            <?php endif; ?>
            <form action="<?php echo e(route('admin.friend.search')); ?>" method="post" >
            <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="col-md-1">
                        <div class="form-group">
                            <input type="text" name="id" class="form-control border-input" value=""  placeholder="ID">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <input type="text" name="fullname" class="form-control border-input" placeholder="Họ tên" value="">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <select name="friend_list" class="form-control border-input">
                                
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <input type="submit" name="search" value="Tìm kiếm" class="is" />
                            <input type="submit" name="reset" value="Hủy tìm kiếm" class="is" />
                        </div>
                    </div>
                </div>
            </form>

            
            <a href="<?php echo e(route('admin.friend.create')); ?>" class="addtop"><img src="<?php echo e($adminUrl); ?>/img/add.png" alt="" /> Thêm</a>
        </div>
        <div class="content table-responsive table-full-width">
            <table class="table table-striped">
                <thead>
                    <th>ID</th>
                    <th>Họ tên</th>
                    <th>Hình ảnh</th>
                    <th>Ngày tạo</th>
                    <th>Thuộc danh sách</th>
                    <th>Chức năng</th>
                </thead>
                <tbody>
                <?php $__currentLoopData = $arFriends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $arFriend): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <?php 
                    $fid = $arFriend['fid'];
                    $name = $arFriend['name'];
                    $cname = $arFriend['cname'];
                    $picture = $arFriend['picture'];
                    $urlPic = Storage::url('app/files/'.$picture);

                    
                    $created_at = $arFriend['created_at'];
                    $cat_id = $arFriend['cat_id'];

                    $urlEdit = route('admin.friend.edit', $fid);
                    $urlDel = route('admin.friend.destroy', $fid);
                    // 01672333193
                ?>
                    <tr>
                        <td><?php echo e($fid); ?></td>
                        <td><a href=""><?php echo e($name); ?></a></td>
                       
                        <td><img src="<?php echo e($urlPic); ?>" alt="" width="50" /></td>
                        
                        <td><?php echo e($created_at); ?></td>
                        <td><?php echo e($cname); ?></td>
                        
                        <td>
                            <a href="<?php echo e($urlEdit); ?>"><img src="<?php echo e($adminUrl); ?>/img/edit.gif" alt="" /> Sửa</a> &nbsp;||&nbsp;
                            <a href="<?php echo e($urlDel); ?>"><img src="<?php echo e($adminUrl); ?>/img/del.gif" alt="" /> Xóa</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>   
                    
                </tbody>

            </table>

            <div class="text-center">
                <?php echo e($arFriends->links()); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>