<?php $__env->startSection('main'); ?>

<div class="col-md-12">
    <div class="card">
        <div class="header">
            
            <div class="row">
                
                <div class="col-md-12">
                    <div class="form-group">
                        <input type="text" name="search" id="search" class="form-control border-input" placeholder="Nhập nội dung tìm kiếm..." value="">
                    </div>
                </div>
            </div>
           

            
            
        </div>
        <div class="content table-responsive table-full-width">
            <table class="table table-striped">
                <thead>
                    <th>ID</th>
                    <th>Họ tên</th>
                    <th>Hình ảnh</th>
                    <th>Ngày tạo</th>
                   
                  
                </thead>
                <tbody>
                  
                    
                </tbody>

            </table>

        </div>
    </div>
</div>
<script type="text/javascript">
    $('#search').on('keyup', function(){
        $value=$(this).val();
        $.ajax({
            url: '/admin/search',
            type: 'GET',
            
            data: {'search': $value},
            success:function(data){
                    $('tbody').html(data);
            }
        });
        
        
    });
    
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>