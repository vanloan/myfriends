

    <footer class="footer">
        <div class="container-fluid">
            <nav class="pull-left">
                <ul>
                    <li>
                        <a href="/">Dự án được phát triển bởi: Trần Nguyễn Gia Huy - Khóa ABC</a>
                    </li>
                </ul>
            </nav>
            <div class="copyright pull-right">
                &copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by <a href="http://vinaenter.edu.vn">VinaEnter Edu</a>
            </div>
        </div>
    </footer>
</div>
</div>


</body>

<!--   Core JS Files   -->
<script src="<?php echo e($adminUrl); ?>/js/jquery-1.10.2.js" type="text/javascript"></script>
<script src="<?php echo e($adminUrl); ?>/js/bootstrap.min.js" type="text/javascript"></script>

<!-- Paper Dashboard Core javascript and methods for Demo purpose -->
<script src="<?php echo e($adminUrl); ?>/js/paper-dashboard.js"></script>

<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
<script src="<?php echo e($adminUrl); ?>/js/demo.js"></script>


</html>
