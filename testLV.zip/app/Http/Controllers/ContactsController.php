<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\ContactRequest;

class ContactsController extends Controller
{
    public function getContact(){
        return view('contacts.index');
    }
    public function postContact(ContactRequest $request){
        $name = $request->name;
        $email = $request->email;
        $phone = $request->phone;
        $message = $request->message;

        DB::table('contacts')->insert([
            'name' => $name, 
            'email' => $email,
            'phone' => $phone,
            'message' => $message
        ]);
        return redirect()->route('public.friend.index');  
    }

}
