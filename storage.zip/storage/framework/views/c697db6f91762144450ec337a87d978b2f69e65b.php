<?php $__env->startSection('main'); ?>

<div class="col-md-12">
    <div class="card">
        <div class="header">
            <h4 class="title">Danh sách video</h4>

            <?php if(Session::get('msg') != ''): ?>
            <p class="category success"><?php echo e(Session::get('msg')); ?></p>
            <?php endif; ?>
            
            <a href="<?php echo e(route('admin.video.create')); ?>" class="addtop"><img src="<?php echo e($adminUrl); ?>/img/add.png" alt="" /> Thêm</a>
        </div>
        <div class="content table-responsive table-full-width">
            <table class="table table-striped">
                <thead>
                    <th>ID</th>
                    <th>Tên danh mục</th>
                    <th>Youtube_code</th>
                    <th>Chức năng</th>
                </thead>
                <tbody>
                <?php $__currentLoopData = $arVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $arVideo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <?php 
                    $vid = $arVideo['vid'];
                    $name = $arVideo['name'];
                    
                    $nameSeo = str_slug($name);
                    $youtube_code = $arVideo['youtube_code'];
                    $urlEdit = route('admin.video.edit', $vid);
                    $urlDel = route('admin.video.destroy', $vid);
                ?>
                    <tr>
                        <td><?php echo e($vid); ?></td>
                        <td><?php echo e($name); ?></td>
                        <td><?php echo e($youtube_code); ?></td>
                        <td>
                            <a href="<?php echo e($urlEdit); ?>"><img src="<?php echo e($adminUrl); ?>/img/edit.gif" alt="" /> Sửa</a> &nbsp;||&nbsp;
                            <a href="<?php echo e($urlDel); ?>"><img src="<?php echo e($adminUrl); ?>/img/del.gif" alt="" /> Xóa</a>
                        </td>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>

            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>