<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\FriendRequest;
use Illuminate\Support\Facades\Storage;

use App\Friend;
use App\Cat;


class FriendController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $arCats = Cat::all();
        $arFriends = Friend::getList();
        return view('admin.friend.index', ['arFriends' => $arFriends, 'arCats' => $arCats]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $arCats = Cat::all();
        return view('admin.friend.create', ['arCats' => $arCats]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(FriendRequest $request)
    {
        $fileName = $request->picture;
        $picture = "";
        if($fileName != ""){
            $path = $request->picture->store('files');
            $tmp = explode('/', $path);
            $picture = end($tmp);
        }
        $arFriend = array(
            'name' => $request->name,
            
            'count_number' => $request->read,
            'cat_id' => $request->friend_list,
            'picture' => $picture,
            'preview' => $request->preview,
            'content' => $request->content,
        );
        Friend::insert($arFriend);
        $request->session()->flash('msg', 'Thêm thành công');
        return redirect()->route('admin.friend.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $arCat = Cat::find($id);
        $arFriends = Friend::where('cat_id', '=', $id)->get();
        return view('admin.friend.show', ['arFriends' => $arFriends,'arCat' => $arCat]);
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $arCats = Cat::all();
        $arFriend = Friend::find($id);
        return view('admin.friend.edit', ['arFriend'=> $arFriend], ['arCats'=> $arCats]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $arFriend = Friend::find($id);
        $arFriend->name = $request->name;
        $arFriend->preview = $request->preview;
        $arFriend->content = $request->content;
        $arFriend->count_number = $request->read;
        $arFriend->created_at = $request->created_at;
        $arFriend->cat_id = $request->friend_list;


        //xu ly hinh anh
        if($request->picture != ''){
            $tenanhcu = $arFriend->picture;
            //up anh moi
            $path = $request->picture->store('files');
            $tmp = explode('/',$path);
            $tenanhmoi = end($tmp);
            $arFriend->picture = $tenanhmoi;

            //xoa anh cu
            $pathOldPic = storage_path('app/files/'.$tenanhcu);
            if(is_file($pathOldPic) && ($tenanhcu != "")){
                Storage::delete('files/'.$tenanhcu);
            }
        }
        //xoa anh neu checkbox dc chon
        if($request->input('delete_picture')){
            $tenanhcu = $arFriend->picture;
            Storage::delete('files/'.$tenanhcu);
        }

        
        $arFriend->Update();

        $request->session()->flash('msg', 'Sửa thành công');
        return redirect()->route('admin.friend.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id, Request $request)
    {
        $arFriend = Friend::find($id);
        $arFriend->delete();
        $request->session()->flash('msg', 'Xóa thành công');
        return redirect()->route('admin.friend.index');
    }
    public function search(Request $request)
    {
        $fullname = $request->fullname;
        
        $arCats = Cat::all();
        $arFriends = Friend::where('name','LIKE',"%$fullname%")->orderBy('fid', 'DESC')->take(4)->paginate(getenv('ROW_COUNT'));
        return view('admin.friend.index', [
            'arFriends'=>$arFriends, 'arCats'=>$arCats, 'fullname'=>$fullname
        ]);
        
    }
    

}

